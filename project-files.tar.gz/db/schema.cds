namespace retail;

using { cuid, managed } from '@sap/cds/common';

entity Stores : cuid {
  name : String(100) not null;
}

entity Products : cuid {
  name : String(100) not null;
}

@assert.unique.stock : [store, product]
entity Inventory : cuid {
  store    : Association to Stores not null;
  product  : Association to Products not null;
  onHand   : Integer default 0 not null;
  reserved : Integer default 0 not null;
}

type TransferStatus : String enum {
  Requested;
  Approved;
  InTransit;
  Received;
}

entity StockTransfers : cuid, managed {
  source      : Association to Stores not null;
  destination : Association to Stores not null;
  product     : Association to Products not null;
  quantity    : Integer not null;
  status      : TransferStatus default 'Requested' not null;
  approvedBy  : String(255);
  approvedAt  : Timestamp;
  dispatchedBy : String(255);
  dispatchedAt : Timestamp;
  receivedBy   : String(255);
  receivedAt   : Timestamp;
}
