#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
npm run build
mkdir -p gen/srv/app
cp -R app/transfers gen/srv/app/
