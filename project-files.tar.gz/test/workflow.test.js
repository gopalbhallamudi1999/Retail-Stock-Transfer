const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { once } = require('node:events');

const source = '10000000-0000-4000-8000-000000000001';
const destination = '10000000-0000-4000-8000-000000000002';
const product = '20000000-0000-4000-8000-000000000001';
const service = '/odata/v4/stock-transfers/';
let server;
let base;

before(async () => {
  server = spawn(process.execPath, ['node_modules/@sap/cds/bin/serve.js'], {
    env: { ...process.env, NODE_ENV: 'development', PORT: '0' }
  });
  server.stderr.pipe(process.stderr);
  await new Promise((resolve, reject) => {
    let output = '';
    server.once('error', reject);
    server.once('exit', () => reject(new Error('CAP stopped before printing the server URL.')));
    server.stdout.on('data', chunk => {
      if (base) return;
      output += chunk;
      const url = output.match(/http:\/\/localhost:\d+/);
      if (url) {
        base = url[0];
        resolve();
      }
    });
  });
}, { timeout: 15000 });

after(async () => {
  if (server && server.exitCode === null) {
    const exit = once(server, 'exit');
    server.kill();
    await exit;
  }
});

async function call(path, user, expected, payload) {
  const headers = { 'content-type': 'application/json' };
  if (user) headers.authorization = 'Basic ' + Buffer.from(user + ':demo').toString('base64');
  const response = await fetch(base + service + path, {
    method: payload === undefined ? 'GET' : 'POST', headers,
    body: payload === undefined ? undefined : JSON.stringify(payload)
  });
  const body = await response.text();
  assert.equal(response.status, expected, body);
  return response.headers.get("content-type")?.includes("application/json") ? JSON.parse(body) : undefined;
}

const request = (user, expected, quantity, overrides = {}) => call(
  'requestTransfer', user, expected, { source, destination, product, quantity, ...overrides }
);
const act = (id, action, user, expected) => call(
  `StockTransfers(${id})/TransferService.${action}`, user, expected, {}
);
async function stock(store) {
  const result = await call(`Inventory?$filter=store_ID eq ${store}`, 'controller', 200);
  const [{ onHand, reserved }] = result.value;
  return { onHand, reserved };
}

test('transfer reserves, ships, and credits stock exactly once', async () => {
  await call('Inventory', null, 401);
  await request('hyderabad', 400, 0);
  await request('hyderabad', 400, 1, { source: destination });
  await request('bengaluru', 403, 1);

  const { ID } = await request('hyderabad', 200, 10);
  await act(ID, 'confirmDispatch', 'bengaluru', 409);
  await act(ID, 'approve', 'hyderabad', 403);
  await act(ID, 'approve', 'controller', 204);
  assert.deepEqual(await stock(source), { onHand: 50, reserved: 10 });

  const excess = await request('hyderabad', 200, 45);
  await act(excess.ID, 'approve', 'controller', 409);
  const pending = await call(`StockTransfers(${excess.ID})`, 'controller', 200);
  assert.equal(pending.status, 'Requested');
  assert.equal(pending.approvedBy, null);

  await act(ID, 'confirmDispatch', 'hyderabad', 403);
  await act(ID, 'confirmDispatch', 'bengaluru', 204);
  assert.deepEqual(await stock(source), { onHand: 40, reserved: 0 });
  assert.deepEqual(await stock(destination), { onHand: 5, reserved: 0 });
  await act(ID, 'receive', 'bengaluru', 403);
  await act(ID, 'receive', 'hyderabad', 204);
  await act(ID, 'receive', 'hyderabad', 409);
  assert.deepEqual(await stock(destination), { onHand: 15, reserved: 0 });
  const final = await call(`StockTransfers(${ID})`, 'controller', 200);
  assert.equal(final.status, 'Received');
  assert.equal(final.createdBy, 'hyderabad');
  assert.equal(final.approvedBy, 'controller');
  assert.equal(final.dispatchedBy, 'bengaluru');
  assert.equal(final.receivedBy, 'hyderabad');
});
