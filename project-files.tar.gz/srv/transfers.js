const cds = require('@sap/cds');
const { SELECT, INSERT, UPDATE } = cds.ql;

module.exports = class TransferService extends cds.ApplicationService {
  init() {
    const { Inventory, StockTransfers } = cds.entities('retail');

    this.on('requestTransfer', async req => {
      const { source, destination, product, quantity } = req.data;
      if (!source || !destination || !product || !Number.isInteger(quantity) || quantity < 1) {
        return req.reject(400, 'Choose two stores, a product, and a positive whole quantity.');
      }
      if (source === destination) return req.reject(400, 'Choose different source and destination stores.');
      const requester = req.user.attr?.StoreID;
      if (!requester || ![requester].flat().includes(destination)) {
        return req.reject(403, 'Only the destination store can request a transfer.');
      }
      const positions = await SELECT.from(Inventory).where({
        product_ID: product, store_ID: { in: [source, destination] }
      });
      if (positions.length !== 2) return req.reject(400, 'The product needs an inventory position at both stores.');

      const ID = cds.utils.uuid();
      await INSERT.into(StockTransfers).entries({
        ID, source_ID: source, destination_ID: destination, product_ID: product, quantity,
        status: 'Requested'
      });
      return SELECT.one.from(StockTransfers, ID);
    });

    const transitions = {
      approve: { from: 'Requested', to: 'Approved', audit: 'approved' },
      confirmDispatch: { from: 'Approved', to: 'InTransit', audit: 'dispatched', store: 'source_ID' },
      receive: { from: 'InTransit', to: 'Received', audit: 'received', store: 'destination_ID' }
    };

    for (const [action, transition] of Object.entries(transitions)) {
      this.on(action, 'StockTransfers', async req => {
        const { ID } = req.params[0];
        const transfer = await SELECT.one.from(StockTransfers, ID);
        if (!transfer) return req.reject(404, 'Transfer not found.');
        if (transition.store && ![req.user.attr?.StoreID].flat().includes(transfer[transition.store])) {
          return req.reject(403, 'This action belongs to the store responsible for this step.');
        }
        if (transfer.status !== transition.from) {
          return req.reject(409, 'This action is unavailable in the current transfer status.');
        }

        // Claim the state transition before updating inventory in the same transaction.
        const changed = await UPDATE(StockTransfers).set({
          status: transition.to,
          [transition.audit + 'By']: req.user.id,
          [transition.audit + 'At']: new Date().toISOString()
        }).where({ ID, status: transition.from });
        if (!changed) return req.reject(409, 'The transfer status has already changed.');

        const { quantity, product_ID } = transfer;
        const key = {
          store_ID: action === 'receive' ? transfer.destination_ID : transfer.source_ID,
          product_ID
        };
        let update = UPDATE(Inventory).where(key);
        if (action === 'approve') {
          update = update.set`reserved = reserved + ${quantity}`.and`onHand - reserved >= ${quantity}`;
        } else if (action === 'confirmDispatch') {
          update = update.set`reserved = reserved - ${quantity}`.set`onHand = onHand - ${quantity}`
            .and`reserved >= ${quantity} and onHand >= ${quantity}`;
        } else {
          update = update.set`onHand = onHand + ${quantity}`;
        }
        if (!(await update)) return req.reject(409, 'Inventory could not be updated. Check the available stock.');
      });
    }

    return super.init();
  }
};
