using { retail } from '../db/schema';

@path: 'stock-transfers'
@requires: ['StoreManager', 'InventoryController']
service TransferService {
  @readonly entity Stores as projection on retail.Stores;
  @readonly entity Products as projection on retail.Products;
  @readonly entity Inventory as projection on retail.Inventory;
  @readonly entity StockTransfers as projection on retail.StockTransfers actions {
    @requires: 'InventoryController' action approve();
    @requires: 'StoreManager' action confirmDispatch();
    @requires: 'StoreManager' action receive();
  };

  @requires: 'StoreManager'
  action requestTransfer(source : UUID, destination : UUID, product : UUID, quantity : Integer) returns StockTransfers;
}
