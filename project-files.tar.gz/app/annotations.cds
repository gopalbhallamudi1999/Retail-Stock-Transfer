using { TransferService } from '../srv/transfers';

annotate TransferService.StockTransfers with @(
  UI.HeaderInfo: {
    TypeName: 'Stock transfer',
    TypeNamePlural: 'Stock transfers',
    Title: { Value: product.name },
    Description: { Value: status }
  },
  UI.SelectionFields: [status],
  UI.LineItem: [
    { Value: product.name, Label: 'Product' },
    { Value: source.name, Label: 'Source store' },
    { Value: destination.name, Label: 'Destination store' },
    { Value: quantity, Label: 'Quantity' },
    { Value: status, Label: 'Status' },
    { $Type: 'UI.DataFieldForAction', Action: 'TransferService.requestTransfer', Label: 'Request transfer' }
  ],
  UI.Identification: [
    { $Type: 'UI.DataFieldForAction', Action: 'TransferService.approve', Label: 'Approve' },
    { $Type: 'UI.DataFieldForAction', Action: 'TransferService.confirmDispatch', Label: 'Dispatch' },
    { $Type: 'UI.DataFieldForAction', Action: 'TransferService.receive', Label: 'Confirm receipt' }
  ],
  UI.Facets: [
    { $Type: 'UI.ReferenceFacet', Label: 'Transfer details', Target: '@UI.FieldGroup#Details' },
    { $Type: 'UI.ReferenceFacet', Label: 'Activity', Target: '@UI.FieldGroup#Activity' }
  ],
  UI.FieldGroup #Details: { Data: [
    { Value: source.name, Label: 'Source store' },
    { Value: destination.name, Label: 'Destination store' },
    { Value: product.name, Label: 'Product' },
    { Value: quantity, Label: 'Quantity' }
  ] },
  UI.FieldGroup #Activity: { Data: [
    { Value: createdBy, Label: 'Requested by' },
    { Value: createdAt, Label: 'Requested at' },
    { Value: approvedBy, Label: 'Approved by' },
    { Value: approvedAt, Label: 'Approved at' },
    { Value: dispatchedBy, Label: 'Dispatched by' },
    { Value: dispatchedAt, Label: 'Dispatched at' },
    { Value: receivedBy, Label: 'Received by' },
    { Value: receivedAt, Label: 'Received at' }
  ] }
);

annotate TransferService.requestTransfer(
  source @title: 'Source store' @Common.ValueList: {
    CollectionPath: 'Stores', Parameters: [
      { $Type: 'Common.ValueListParameterInOut', LocalDataProperty: source, ValueListProperty: 'ID' },
      { $Type: 'Common.ValueListParameterDisplayOnly', ValueListProperty: 'name' }
    ]
  },
  destination @title: 'Destination store' @Common.ValueList: {
    CollectionPath: 'Stores', Parameters: [
      { $Type: 'Common.ValueListParameterInOut', LocalDataProperty: destination, ValueListProperty: 'ID' },
      { $Type: 'Common.ValueListParameterDisplayOnly', ValueListProperty: 'name' }
    ]
  },
  product @title: 'Product' @Common.ValueList: {
    CollectionPath: 'Products', Parameters: [
      { $Type: 'Common.ValueListParameterInOut', LocalDataProperty: product, ValueListProperty: 'ID' },
      { $Type: 'Common.ValueListParameterDisplayOnly', ValueListProperty: 'name' }
    ]
  },
  quantity @title: 'Quantity'
);

annotate TransferService.StockTransfers actions {
  approve @Common.SideEffects.TargetEntities: [in];
  confirmDispatch @Common.SideEffects.TargetEntities: [in];
  receive @Common.SideEffects.TargetEntities: [in];
};
